import sys

p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
if 'RECORD_AUDIO' in s:
    print('Manifest already patched.')
    sys.exit(0)

block = '''    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <queries>
        <intent><action android:name="android.speech.RecognitionService"/></intent>
        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>
        <intent>
            <action android:name="android.intent.action.VIEW"/>
            <data android:scheme="https"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW"/>
            <data android:scheme="tel"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.SENDTO"/>
            <data android:scheme="sms"/>
        </intent>
    </queries>
'''
if '<application' not in s:
    print('ERROR: <application> not found'); sys.exit(1)
s = s.replace('<application', block + '    <application', 1)
open(p, 'w', encoding='utf-8').write(s)
print('Manifest patched: permissions + queries added.')
