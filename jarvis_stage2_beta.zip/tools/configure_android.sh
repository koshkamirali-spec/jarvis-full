#!/bin/sh
# Sets applicationId=com.jarvis.ai, label, minSdk 24, permissions.
set -e
for f in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$f" ] || continue
  sed -E -i.bak 's/applicationId[ =]+"com\.jarvis\.jarvis_ai"/applicationId = "com.jarvis.ai"/' "$f"
  sed -E -i.bak 's/minSdk(Version)?[ =]+flutter\.minSdkVersion/minSdk = 24/' "$f"
  rm -f "$f.bak"
  grep -nE 'applicationId|minSdk' "$f"
done
M=android/app/src/main/AndroidManifest.xml
sed -i.bak 's/android:label="jarvis_ai"/android:label="J.A.R.V.I.S"/' "$M"
rm -f "$M.bak"
python3 tools/patch_manifest.py
echo "Android configured."
