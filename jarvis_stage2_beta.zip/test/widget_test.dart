import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis_ai/features/assistant/jarvis_orb.dart';

void main() {
  testWidgets('orb renders in every state', (tester) async {
    for (final s in JarvisState.values) {
      await tester.pumpWidget(
        MaterialApp(home: Scaffold(body: JarvisOrb(state: s))),
      );
      await tester.pump(const Duration(milliseconds: 120));
      expect(find.byType(JarvisOrb), findsOneWidget);
    }
  });
}
