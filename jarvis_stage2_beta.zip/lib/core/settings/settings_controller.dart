import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLang = 'settings.lang';
const _kTheme = 'settings.theme';
const _kName = 'settings.assistantName';
const _kOnboarded = 'settings.onboarded';
const _kSpeak = 'settings.speakReplies';
const _kRate = 'settings.speechRate';
const _kEmNumber = 'settings.emergencyNumber';
const _kMemory = 'settings.memoryEnabled';

/// Overridden in main() with the real instance.
final sharedPrefsProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('sharedPrefsProvider not overridden'),
);

class SettingsState {
  const SettingsState({
    required this.languageCode,
    required this.themeMode,
    required this.assistantName,
    required this.onboarded,
    required this.speakReplies,
    required this.speechRate,
    required this.emergencyNumber,
    required this.memoryEnabled,
  });

  final String languageCode;
  final ThemeMode themeMode;
  final String assistantName;
  final bool onboarded;
  final bool speakReplies;
  final double speechRate;
  final String emergencyNumber;
  final bool memoryEnabled;

  Locale get locale => Locale(languageCode);

  SettingsState copyWith({
    String? languageCode,
    ThemeMode? themeMode,
    String? assistantName,
    bool? onboarded,
    bool? speakReplies,
    double? speechRate,
    String? emergencyNumber,
    bool? memoryEnabled,
  }) =>
      SettingsState(
        languageCode: languageCode ?? this.languageCode,
        themeMode: themeMode ?? this.themeMode,
        assistantName: assistantName ?? this.assistantName,
        onboarded: onboarded ?? this.onboarded,
        speakReplies: speakReplies ?? this.speakReplies,
        speechRate: speechRate ?? this.speechRate,
        emergencyNumber: emergencyNumber ?? this.emergencyNumber,
        memoryEnabled: memoryEnabled ?? this.memoryEnabled,
      );
}

ThemeMode _parseTheme(String? v) {
  for (final m in ThemeMode.values) {
    if (m.name == v) return m;
  }
  return ThemeMode.dark;
}

class SettingsController extends StateNotifier<SettingsState> {
  SettingsController(this._prefs)
      : super(SettingsState(
          languageCode: _prefs.getString(_kLang) ?? 'fa',
          themeMode: _parseTheme(_prefs.getString(_kTheme)),
          assistantName: _prefs.getString(_kName) ?? 'Jarvis',
          onboarded: _prefs.getBool(_kOnboarded) ?? false,
          speakReplies: _prefs.getBool(_kSpeak) ?? true,
          speechRate: _prefs.getDouble(_kRate) ?? 0.5,
          emergencyNumber: _prefs.getString(_kEmNumber) ?? '',
          memoryEnabled: _prefs.getBool(_kMemory) ?? true,
        ));

  final SharedPreferences _prefs;

  Future<void> setLanguage(String code) async {
    state = state.copyWith(languageCode: code);
    await _prefs.setString(_kLang, code);
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    state = state.copyWith(themeMode: mode);
    await _prefs.setString(_kTheme, mode.name);
  }

  Future<void> setAssistantName(String name) async {
    final clean = name.trim().isEmpty ? 'Jarvis' : name.trim();
    state = state.copyWith(assistantName: clean);
    await _prefs.setString(_kName, clean);
  }

  Future<void> completeOnboarding(String name) async {
    final clean = name.trim().isEmpty ? 'Jarvis' : name.trim();
    state = state.copyWith(assistantName: clean, onboarded: true);
    await _prefs.setString(_kName, clean);
    await _prefs.setBool(_kOnboarded, true);
  }

  Future<void> setSpeakReplies(bool v) async {
    state = state.copyWith(speakReplies: v);
    await _prefs.setBool(_kSpeak, v);
  }

  Future<void> setSpeechRate(double v) async {
    state = state.copyWith(speechRate: v);
    await _prefs.setDouble(_kRate, v);
  }

  Future<void> setEmergencyNumber(String v) async {
    final clean = v.replaceAll(RegExp(r'\s'), '');
    state = state.copyWith(emergencyNumber: clean);
    await _prefs.setString(_kEmNumber, clean);
  }

  Future<void> setMemoryEnabled(bool v) async {
    state = state.copyWith(memoryEnabled: v);
    await _prefs.setBool(_kMemory, v);
  }
}

final settingsProvider =
    StateNotifierProvider<SettingsController, SettingsState>(
  (ref) => SettingsController(ref.watch(sharedPrefsProvider)),
);
