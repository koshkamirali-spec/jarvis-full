import 'package:flutter/material.dart';

import 'jarvis_colors.dart';

class AppTheme {
  AppTheme._();

  static ThemeData dark() {
    const scheme = ColorScheme.dark(
      primary: JarvisColors.cyan,
      secondary: JarvisColors.electric,
      tertiary: JarvisColors.turquoise,
      surface: JarvisColors.panel,
      onSurface: JarvisColors.text,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: JarvisColors.bg,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: JarvisColors.text,
      ),
    );
  }

  static ThemeData light() {
    const scheme = ColorScheme.light(
      primary: JarvisColors.deepBlue,
      secondary: JarvisColors.electric,
      tertiary: JarvisColors.turquoise,
      surface: Colors.white,
      onSurface: JarvisColors.lightText,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: scheme,
      scaffoldBackgroundColor: JarvisColors.lightBg,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: JarvisColors.lightText,
      ),
    );
  }
}
