import 'package:flutter/material.dart';

/// Palette: deep black, neon blue, turquoise, electric blue, white text.
class JarvisColors {
  JarvisColors._();

  static const Color bg = Color(0xFF03060D);
  static const Color panel = Color(0xFF0A1220);
  static const Color cyan = Color(0xFF00E5FF);
  static const Color electric = Color(0xFF2979FF);
  static const Color turquoise = Color(0xFF1DE9B6);
  static const Color text = Color(0xFFEAF6FF);

  static const Color lightBg = Color(0xFFEFF6FB);
  static const Color deepBlue = Color(0xFF0A5C99);
  static const Color lightText = Color(0xFF07202F);

  /// Alpha helper that works on every Flutter version (no deprecated APIs).
  static Color alpha(Color c, double opacity) =>
      c.withAlpha((opacity.clamp(0.0, 1.0) * 255).round());
}
