import 'package:flutter/widgets.dart';

/// Persian/English string table.
class S {
  S(this.lang);
  final String lang;

  static S of(BuildContext context) =>
      S(Localizations.localeOf(context).languageCode);

  String t(String key) => _m[key]?[lang] ?? _m[key]?['en'] ?? key;

  String weekday(int weekday) {
    final list = lang == 'fa' ? _weekFa : _weekEn;
    return list[(weekday - 1).clamp(0, 6)];
  }

  static const _weekFa = [
    'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه', 'یکشنبه'
  ];
  static const _weekEn = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday',
    'Sunday'
  ];

  static const Map<String, Map<String, String>> _m = {
    'welcomeTitle': {
      'fa': 'سلام! من جارویس هستم.',
      'en': 'Hello! I am Jarvis.',
    },
    'welcomeBody': {
      'fa': 'دوست داری مرا با چه نامی صدا کنی؟',
      'en': 'What would you like to call me?',
    },
    'nameHint': {'fa': 'مثلاً جارویس', 'en': 'e.g. Jarvis'},
    'start': {'fa': 'شروع', 'en': 'Start'},
    'tapMic': {'fa': 'میکروفون را لمس کنید', 'en': 'Tap the microphone'},
    'settings': {'fa': 'تنظیمات', 'en': 'Settings'},
    'language': {'fa': 'زبان', 'en': 'Language'},
    'persian': {'fa': 'فارسی', 'en': 'Persian'},
    'english': {'fa': 'انگلیسی', 'en': 'English'},
    'theme': {'fa': 'تم', 'en': 'Theme'},
    'themeSystem': {'fa': 'سیستم', 'en': 'System'},
    'themeDark': {'fa': 'تاریک', 'en': 'Dark'},
    'themeLight': {'fa': 'روشن', 'en': 'Light'},
    'assistantName': {'fa': 'نام دستیار', 'en': 'Assistant name'},
    'save': {'fa': 'ذخیره', 'en': 'Save'},
    'saved': {'fa': 'ذخیره شد', 'en': 'Saved'},
    'battery': {'fa': 'باتری', 'en': 'Battery'},
    'charging': {'fa': 'در حال شارژ', 'en': 'Charging'},
    'network': {'fa': 'شبکه', 'en': 'Network'},
    'wifi': {'fa': 'Wi-Fi', 'en': 'Wi-Fi'},
    'mobile': {'fa': 'اینترنت همراه', 'en': 'Mobile data'},
    'ethernet': {'fa': 'کابلی', 'en': 'Ethernet'},
    'offline': {'fa': 'آفلاین', 'en': 'Offline'},
    'unknown': {'fa': 'نامشخص', 'en': 'Unknown'},
    'ai': {'fa': 'هوش مصنوعی', 'en': 'AI'},
    'aiReady': {'fa': 'آماده', 'en': 'Ready'},
    'aiNotConnected': {'fa': 'کلید وارد نشده', 'en': 'No key'},
    'idle': {'fa': 'آماده', 'en': 'Ready'},
    'listening': {'fa': 'در حال گوش دادن', 'en': 'Listening'},
    'thinking': {'fa': 'در حال پردازش', 'en': 'Thinking'},
    'speaking': {'fa': 'در حال صحبت', 'en': 'Speaking'},
    'chat': {'fa': 'گفتگو', 'en': 'Chat'},
    'vision': {'fa': 'بینایی', 'en': 'Vision'},
    'emergency': {'fa': 'اضطراری', 'en': 'Emergency'},
    'memory': {'fa': 'حافظه', 'en': 'Memory'},
    'planner': {'fa': 'برنامه', 'en': 'Planner'},
    'send': {'fa': 'ارسال', 'en': 'Send'},
    'typeMessage': {'fa': 'پیام بنویسید…', 'en': 'Type a message…'},
    'noKey': {
      'fa': 'کلید API وارد نشده است. از تنظیمات، کلید خود را اضافه کنید.',
      'en': 'No API key set. Add your key in Settings.',
    },
    'errKey': {'fa': 'کلید API نامعتبر است.', 'en': 'The API key is invalid.'},
    'errRate': {
      'fa': 'درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید.',
      'en': 'Too many requests. Try again shortly.',
    },
    'errNet': {'fa': 'اتصال اینترنت برقرار نیست.', 'en': 'No internet connection.'},
    'errGeneric': {
      'fa': 'خطا در ارتباط با هوش مصنوعی.',
      'en': 'The AI request failed.',
    },
    'micFail': {
      'fa': 'دسترسی به میکروفون یا تشخیص گفتار ممکن نیست. مجوز میکروفون را بررسی کنید.',
      'en': 'Microphone or speech recognition is unavailable. Check the microphone permission.',
    },
    'faMissing': {
      'fa': 'بسته‌ی تشخیص گفتار فارسی روی این گوشی پیدا نشد؛ ممکن است تشخیص دقیق نباشد.',
      'en': 'Persian speech recognition was not found on this phone.',
    },
    'apiKey': {'fa': 'کلید API (Anthropic)', 'en': 'API key (Anthropic)'},
    'apiKeyNote': {
      'fa': 'کلید فقط روی همین گوشی و به‌صورت رمزنگاری‌شده ذخیره می‌شود.',
      'en': 'The key is stored only on this phone, encrypted.',
    },
    'keySaved': {'fa': 'کلید ذخیره شده است', 'en': 'Key is saved'},
    'keyMissing': {'fa': 'کلید ذخیره نشده', 'en': 'No key saved'},
    'clear': {'fa': 'پاک کردن', 'en': 'Clear'},
    'speakReplies': {'fa': 'خواندن پاسخ‌ها با صدا', 'en': 'Speak replies'},
    'speechRate': {'fa': 'سرعت صدا', 'en': 'Speech speed'},
    'camera': {'fa': 'دوربین', 'en': 'Camera'},
    'gallery': {'fa': 'گالری', 'en': 'Gallery'},
    'modeDescribe': {'fa': 'توضیح تصویر', 'en': 'Describe'},
    'modeText': {'fa': 'استخراج متن', 'en': 'Read text'},
    'modeProduct': {'fa': 'شناسایی', 'en': 'Identify'},
    'analyzing': {'fa': 'در حال تحلیل…', 'en': 'Analyzing…'},
    'pickHint': {
      'fa': 'یک عکس بگیرید یا از گالری انتخاب کنید.',
      'en': 'Take a photo or pick one from the gallery.',
    },
    'speak': {'fa': 'بخوان', 'en': 'Read aloud'},
    'copy': {'fa': 'کپی', 'en': 'Copy'},
    'copied': {'fa': 'کپی شد', 'en': 'Copied'},
    'contacts': {'fa': 'مخاطبان مورد اعتماد', 'en': 'Trusted contacts'},
    'addContact': {'fa': 'افزودن مخاطب', 'en': 'Add contact'},
    'name': {'fa': 'نام', 'en': 'Name'},
    'phone': {'fa': 'شماره', 'en': 'Phone'},
    'add': {'fa': 'افزودن', 'en': 'Add'},
    'cancel': {'fa': 'انصراف', 'en': 'Cancel'},
    'noContacts': {'fa': 'هنوز مخاطبی اضافه نشده.', 'en': 'No contacts yet.'},
    'emergencyNumber': {
      'fa': 'شماره اضطراری (اختیاری)',
      'en': 'Emergency number (optional)',
    },
    'emergencyDialogTitle': {'fa': 'چه کاری انجام شود؟', 'en': 'What should happen?'},
    'emergencyNote': {
      'fa': 'هیچ تماس یا پیامی بدون تأیید شما انجام نمی‌شود. پیامک در برنامه‌ی پیام آماده می‌شود و ارسال را شما می‌زنید.',
      'en': 'Nothing is called or sent without your confirmation. The text opens in your SMS app and you press send.',
    },
    'callEmergency': {'fa': 'تماس با شماره اضطراری', 'en': 'Call emergency number'},
    'callContact': {'fa': 'تماس با اولین مخاطب', 'en': 'Call first contact'},
    'smsLocation': {'fa': 'آماده‌سازی پیامک با موقعیت', 'en': 'Prepare SMS with location'},
    'locationFail': {
      'fa': 'موقعیت دریافت نشد؛ پیامک بدون موقعیت آماده شد.',
      'en': 'Location unavailable; message prepared without it.',
    },
    'smsBody': {'fa': 'اضطراری! نیاز به کمک دارم.', 'en': 'Emergency! I need help.'},
    'needNumber': {'fa': 'اول شماره را وارد کنید.', 'en': 'Enter a number first.'},
    'memoryHint': {'fa': 'چیزی که باید به یاد بماند…', 'en': 'Something to remember…'},
    'memoryEnabled': {'fa': 'استفاده از حافظه در پاسخ‌ها', 'en': 'Use memory in replies'},
    'memoryEmpty': {'fa': 'حافظه خالی است.', 'en': 'Memory is empty.'},
    'memoryNote': {
      'fa': 'فقط چیزهایی که خودتان اضافه می‌کنید ذخیره می‌شود.',
      'en': 'Only what you add here is stored.',
    },
    'taskHint': {'fa': 'کار جدید…', 'en': 'New task…'},
    'tasksEmpty': {'fa': 'کاری ثبت نشده.', 'en': 'No tasks yet.'},
  };
}
