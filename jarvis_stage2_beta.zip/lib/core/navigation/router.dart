import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/assistant/chat_page.dart';
import '../../features/assistant/home_page.dart';
import '../../features/assistant/onboarding_page.dart';
import '../../features/emergency/emergency_page.dart';
import '../../features/memory/memory_page.dart';
import '../../features/planner/planner_page.dart';
import '../../features/settings/settings_page.dart';
import '../../features/vision/vision_page.dart';
import '../settings/settings_controller.dart';

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/',
    redirect: (context, state) {
      final onboarded = ref.read(settingsProvider).onboarded;
      final atWelcome = state.matchedLocation == '/welcome';
      if (!onboarded && !atWelcome) return '/welcome';
      if (onboarded && atWelcome) return '/';
      return null;
    },
    routes: [
      GoRoute(path: '/', builder: (context, state) => const HomePage()),
      GoRoute(
          path: '/welcome',
          builder: (context, state) => const OnboardingPage()),
      GoRoute(path: '/chat', builder: (context, state) => const ChatPage()),
      GoRoute(path: '/vision', builder: (context, state) => const VisionPage()),
      GoRoute(
          path: '/emergency',
          builder: (context, state) => const EmergencyPage()),
      GoRoute(path: '/memory', builder: (context, state) => const MemoryPage()),
      GoRoute(
          path: '/planner', builder: (context, state) => const PlannerPage()),
      GoRoute(
          path: '/settings',
          builder: (context, state) => const SettingsPage()),
    ],
  );
});
