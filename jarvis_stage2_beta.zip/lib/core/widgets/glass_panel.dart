import 'dart:ui';

import 'package:flutter/material.dart';

import '../theme/jarvis_colors.dart';

/// Frosted-glass panel used across the HUD.
class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 20,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final tint = dark ? JarvisColors.cyan : JarvisColors.deepBlue;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: JarvisColors.alpha(tint, dark ? 0.07 : 0.08),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: JarvisColors.alpha(tint, 0.28)),
          ),
          child: child,
        ),
      ),
    );
  }
}
