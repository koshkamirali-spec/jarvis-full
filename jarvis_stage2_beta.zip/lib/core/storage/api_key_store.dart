import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// API key kept in the Android Keystore-backed secure storage.
final apiKeyProvider =
    StateNotifierProvider<ApiKeyController, String?>((ref) => ApiKeyController());

class ApiKeyController extends StateNotifier<String?> {
  ApiKeyController() : super(null) {
    _load();
  }

  static const _k = 'anthropic_api_key';
  final FlutterSecureStorage _s = const FlutterSecureStorage();

  Future<void> _load() async {
    try {
      final v = await _s.read(key: _k);
      if (mounted) state = (v == null || v.isEmpty) ? null : v;
    } catch (_) {}
  }

  Future<void> save(String value) async {
    final t = value.trim();
    try {
      if (t.isEmpty) {
        await _s.delete(key: _k);
      } else {
        await _s.write(key: _k, value: t);
      }
    } catch (_) {}
    state = t.isEmpty ? null : t;
  }
}
