import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../settings/settings_controller.dart';

/// A persisted list of small JSON maps (contacts, memory facts, tasks).
class JsonListController extends StateNotifier<List<Map<String, dynamic>>> {
  JsonListController(this._prefs, this._key) : super(_read(_prefs, _key));

  final SharedPreferences _prefs;
  final String _key;

  static List<Map<String, dynamic>> _read(SharedPreferences p, String k) {
    final raw = p.getString(k);
    if (raw == null) return [];
    try {
      final d = jsonDecode(raw) as List;
      return d.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _save() => _prefs.setString(_key, jsonEncode(state));

  Future<void> add(Map<String, dynamic> item) async {
    state = [...state, item];
    await _save();
  }

  Future<void> removeAt(int i) async {
    final l = [...state]..removeAt(i);
    state = l;
    await _save();
  }

  Future<void> update(int i, Map<String, dynamic> item) async {
    final l = [...state];
    l[i] = item;
    state = l;
    await _save();
  }
}

typedef JsonListProvider
    = StateNotifierProvider<JsonListController, List<Map<String, dynamic>>>;

final JsonListProvider contactsProvider = StateNotifierProvider(
    (ref) => JsonListController(ref.watch(sharedPrefsProvider), 'data.contacts'));
final JsonListProvider memoryProvider = StateNotifierProvider(
    (ref) => JsonListController(ref.watch(sharedPrefsProvider), 'data.memory'));
final JsonListProvider tasksProvider = StateNotifierProvider(
    (ref) => JsonListController(ref.watch(sharedPrefsProvider), 'data.tasks'));
