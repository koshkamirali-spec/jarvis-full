import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/storage/json_list_store.dart';

class PlannerPage extends ConsumerStatefulWidget {
  const PlannerPage({super.key});

  @override
  ConsumerState<PlannerPage> createState() => _PlannerPageState();
}

class _PlannerPageState extends ConsumerState<PlannerPage> {
  final _text = TextEditingController();

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    _text.clear();
    await ref.read(tasksProvider.notifier).add({'text': t, 'done': false});
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final tasks = ref.watch(tasksProvider);
    final ctrl = ref.read(tasksProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: Text(s.t('planner'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _text,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _add(),
            decoration: InputDecoration(
              hintText: s.t('taskHint'),
              border: const OutlineInputBorder(),
              suffixIcon:
                  IconButton(icon: const Icon(Icons.add), onPressed: _add),
            ),
          ),
          const SizedBox(height: 12),
          if (tasks.isEmpty)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(s.t('tasksEmpty')),
            ),
          for (var i = 0; i < tasks.length; i++)
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              value: tasks[i]['done'] == true,
              title: Text(
                (tasks[i]['text'] as String?) ?? '',
                style: tasks[i]['done'] == true
                    ? const TextStyle(decoration: TextDecoration.lineThrough)
                    : null,
              ),
              secondary: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () => ctrl.removeAt(i),
              ),
              onChanged: (v) => ctrl.update(i, {...tasks[i], 'done': v ?? false}),
            ),
        ],
      ),
    );
  }
}
