import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../core/l10n/strings.dart';
import '../assistant/assistant_controller.dart';

/// Camera / gallery -> describe, read text (OCR), or identify.
class VisionPage extends ConsumerStatefulWidget {
  const VisionPage({super.key});

  @override
  ConsumerState<VisionPage> createState() => _VisionPageState();
}

class _VisionPageState extends ConsumerState<VisionPage> {
  final _picker = ImagePicker();
  Uint8List? _bytes;
  String _mode = 'describe';
  String? _result;
  bool _busy = false;

  String _prompt(String lang) {
    final l = lang == 'fa' ? 'Persian' : 'English';
    switch (_mode) {
      case 'text':
        return 'Extract all visible text from this image exactly as written (Persian and English). Output only the text. If there is no text, say so in $l.';
      case 'product':
        return 'Identify the main product or object in this image. In $l, give its name, what it is, and a short search phrase to find or compare it online. Do not invent prices or links.';
      default:
        return 'Describe this image briefly and clearly in $l. Mention the most important objects and any readable text.';
    }
  }

  Future<void> _pick(ImageSource src) async {
    final s = S.of(context);
    try {
      final x = await _picker.pickImage(
          source: src, maxWidth: 1280, imageQuality: 80);
      if (x == null) return;
      final b = await x.readAsBytes();
      if (!mounted) return;
      setState(() {
        _bytes = b;
        _result = null;
      });
      await _analyze();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(s.t('errGeneric'))));
    }
  }

  Future<void> _analyze() async {
    final bytes = _bytes;
    if (bytes == null) return;
    final lang = S.of(context).lang;
    setState(() {
      _busy = true;
      _result = null;
    });
    String out;
    try {
      out = await ref
          .read(assistantProvider.notifier)
          .analyzeImage(bytes, _prompt(lang));
    } catch (e) {
      out = AssistantController.errorText(e, lang);
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      _result = out;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.t('vision'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'describe', label: Text(s.t('modeDescribe'))),
              ButtonSegment(value: 'text', label: Text(s.t('modeText'))),
              ButtonSegment(value: 'product', label: Text(s.t('modeProduct'))),
            ],
            selected: {_mode},
            onSelectionChanged: (v) {
              setState(() => _mode = v.first);
              if (_bytes != null && !_busy) _analyze();
            },
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _busy ? null : () => _pick(ImageSource.camera),
                  icon: const Icon(Icons.camera_alt),
                  label: Text(s.t('camera')),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _busy ? null : () => _pick(ImageSource.gallery),
                  icon: const Icon(Icons.photo_library_outlined),
                  label: Text(s.t('gallery')),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (_bytes == null)
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text(s.t('pickHint'), textAlign: TextAlign.center),
            )
          else
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.memory(_bytes!, fit: BoxFit.cover, height: 220),
            ),
          const SizedBox(height: 16),
          if (_busy)
            Column(children: [
              const LinearProgressIndicator(),
              const SizedBox(height: 8),
              Text(s.t('analyzing')),
            ]),
          if (_result != null) ...[
            SelectableText(_result!,
                style: Theme.of(context).textTheme.bodyLarge),
            const SizedBox(height: 12),
            Row(
              children: [
                OutlinedButton.icon(
                  onPressed: () => ref
                      .read(assistantProvider.notifier)
                      .speakText(_result!),
                  icon: const Icon(Icons.volume_up),
                  label: Text(s.t('speak')),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: _result!));
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(s.t('copied'))));
                  },
                  icon: const Icon(Icons.copy),
                  label: Text(s.t('copy')),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
