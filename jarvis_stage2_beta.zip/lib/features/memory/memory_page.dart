import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/storage/json_list_store.dart';

class MemoryPage extends ConsumerStatefulWidget {
  const MemoryPage({super.key});

  @override
  ConsumerState<MemoryPage> createState() => _MemoryPageState();
}

class _MemoryPageState extends ConsumerState<MemoryPage> {
  final _text = TextEditingController();

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _add() async {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    _text.clear();
    await ref.read(memoryProvider.notifier).add({'text': t});
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final items = ref.watch(memoryProvider);
    final settings = ref.watch(settingsProvider);

    return Scaffold(
      appBar: AppBar(title: Text(s.t('memory'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('memoryEnabled')),
            value: settings.memoryEnabled,
            onChanged: (v) =>
                ref.read(settingsProvider.notifier).setMemoryEnabled(v),
          ),
          Text(s.t('memoryNote'), style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 12),
          TextField(
            controller: _text,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _add(),
            decoration: InputDecoration(
              hintText: s.t('memoryHint'),
              border: const OutlineInputBorder(),
              suffixIcon:
                  IconButton(icon: const Icon(Icons.add), onPressed: _add),
            ),
          ),
          const SizedBox(height: 12),
          if (items.isEmpty)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(s.t('memoryEmpty')),
            ),
          for (var i = 0; i < items.length; i++)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text((items[i]['text'] as String?) ?? ''),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () => ref.read(memoryProvider.notifier).removeAt(i),
              ),
            ),
        ],
      ),
    );
  }
}
