import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/storage/api_key_store.dart';

class SettingsPage extends ConsumerStatefulWidget {
  const SettingsPage({super.key});

  @override
  ConsumerState<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends ConsumerState<SettingsPage> {
  late final TextEditingController _name;
  final _key = TextEditingController();

  @override
  void initState() {
    super.initState();
    _name =
        TextEditingController(text: ref.read(settingsProvider).assistantName);
  }

  @override
  void dispose() {
    _name.dispose();
    _key.dispose();
    super.dispose();
  }

  void _snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _saveName() async {
    await ref.read(settingsProvider.notifier).setAssistantName(_name.text);
    _snack(S.of(context).t('saved'));
  }

  Future<void> _saveKey() async {
    final msg = S.of(context).t('saved');
    await ref.read(apiKeyProvider.notifier).save(_key.text);
    _key.clear();
    _snack(msg);
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final settings = ref.watch(settingsProvider);
    final ctrl = ref.read(settingsProvider.notifier);
    final hasKey = ref.watch(apiKeyProvider) != null;
    final titleStyle = Theme.of(context).textTheme.titleMedium;

    return Scaffold(
      appBar: AppBar(title: Text(s.t('settings'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(s.t('apiKey'), style: titleStyle),
          const SizedBox(height: 4),
          Text(hasKey ? s.t('keySaved') : s.t('keyMissing'),
              style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 8),
          TextField(
            controller: _key,
            obscureText: true,
            autocorrect: false,
            enableSuggestions: false,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              hintText: 'sk-ant-…',
            ),
          ),
          const SizedBox(height: 4),
          Text(s.t('apiKeyNote'), style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (hasKey)
                TextButton(
                  onPressed: () async {
                    await ref.read(apiKeyProvider.notifier).save('');
                  },
                  child: Text(s.t('clear')),
                ),
              const SizedBox(width: 8),
              FilledButton(onPressed: _saveKey, child: Text(s.t('save'))),
            ],
          ),
          const Divider(height: 32),
          Text(s.t('language'), style: titleStyle),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'fa', label: Text(s.t('persian'))),
              ButtonSegment(value: 'en', label: Text(s.t('english'))),
            ],
            selected: {settings.languageCode},
            onSelectionChanged: (v) => ctrl.setLanguage(v.first),
          ),
          const SizedBox(height: 24),
          Text(s.t('theme'), style: titleStyle),
          const SizedBox(height: 8),
          SegmentedButton<ThemeMode>(
            segments: [
              ButtonSegment(
                  value: ThemeMode.system, label: Text(s.t('themeSystem'))),
              ButtonSegment(
                  value: ThemeMode.dark, label: Text(s.t('themeDark'))),
              ButtonSegment(
                  value: ThemeMode.light, label: Text(s.t('themeLight'))),
            ],
            selected: {settings.themeMode},
            onSelectionChanged: (v) => ctrl.setThemeMode(v.first),
          ),
          const SizedBox(height: 24),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.t('speakReplies')),
            value: settings.speakReplies,
            onChanged: ctrl.setSpeakReplies,
          ),
          Text(s.t('speechRate'), style: titleStyle),
          Slider(
            value: settings.speechRate.clamp(0.2, 0.8),
            min: 0.2,
            max: 0.8,
            divisions: 6,
            onChanged: ctrl.setSpeechRate,
          ),
          const SizedBox(height: 16),
          Text(s.t('assistantName'), style: titleStyle),
          const SizedBox(height: 8),
          TextField(
            controller: _name,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _saveName(),
            decoration: const InputDecoration(border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          Align(
            alignment: AlignmentDirectional.centerEnd,
            child:
                FilledButton(onPressed: _saveName, child: Text(s.t('save'))),
          ),
        ],
      ),
    );
  }
}
