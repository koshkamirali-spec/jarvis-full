import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/theme/jarvis_colors.dart';

enum JarvisState { idle, listening, thinking, speaking }

/// The animated core: glowing nucleus + rotating light rings.
/// idle: slow pulse | listening: expanding ripples
/// thinking: fast sweeping arcs | speaking: sound-wave ring
class JarvisOrb extends StatefulWidget {
  const JarvisOrb({super.key, required this.state, this.size = 260});

  final JarvisState state;
  final double size;

  @override
  State<JarvisOrb> createState() => _JarvisOrbState();
}

class _JarvisOrbState extends State<JarvisOrb>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 6),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return RepaintBoundary(
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) => CustomPaint(
            painter: _OrbPainter(_c.value, widget.state, dark),
          ),
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  _OrbPainter(this.t, this.state, this.dark);

  final double t; // 0..1 over 6 seconds
  final JarvisState state;
  final bool dark;

  // Integer multipliers keep the animation seamless at the loop boundary.
  int get _speed {
    switch (state) {
      case JarvisState.idle:
        return 1;
      case JarvisState.listening:
        return 2;
      case JarvisState.thinking:
        return 4;
      case JarvisState.speaking:
        return 2;
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final a = t * 2 * math.pi * _speed;
    final main = dark ? JarvisColors.cyan : JarvisColors.deepBlue;
    final pulse = 0.5 + 0.5 * math.sin(t * 2 * math.pi * (_speed + 1));

    // Outer halo
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = RadialGradient(colors: [
          JarvisColors.alpha(main, 0.16),
          JarvisColors.alpha(main, 0.0),
        ]).createShader(Rect.fromCircle(center: c, radius: r)),
    );

    // Nucleus
    final coreR = r * (0.30 + 0.04 * pulse);
    canvas.drawCircle(
      c,
      coreR * 1.6,
      Paint()
        ..shader = RadialGradient(colors: [
          JarvisColors.alpha(JarvisColors.cyan, 0.55),
          JarvisColors.alpha(JarvisColors.electric, 0.20),
          JarvisColors.alpha(JarvisColors.electric, 0.0),
        ], stops: const [
          0.0,
          0.55,
          1.0
        ]).createShader(Rect.fromCircle(center: c, radius: coreR * 1.6)),
    );
    canvas.drawCircle(
      c,
      coreR * 0.55,
      Paint()
        ..color = dark ? Colors.white : JarvisColors.alpha(Colors.white, 0.9),
    );

    // Rotating ring arcs
    for (var i = 0; i < 4; i++) {
      final rr = r * (0.52 + 0.12 * i);
      final dir = i.isEven ? 1 : -1;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 2.0 - i * 0.2
        ..color = JarvisColors.alpha(
            i.isEven ? main : JarvisColors.electric, 0.85 - i * 0.12);
      final start = a * dir + i * 0.9;
      for (var k = 0; k < 3; k++) {
        canvas.drawArc(
          Rect.fromCircle(center: c, radius: rr),
          start + k * (2 * math.pi / 3),
          math.pi / (state == JarvisState.thinking ? 2.2 : 3.2),
          false,
          paint,
        );
      }
    }

    // Listening: expanding ripples
    if (state == JarvisState.listening) {
      for (var k = 0; k < 3; k++) {
        final p = (t * 2 + k / 3) % 1.0;
        canvas.drawCircle(
          c,
          r * (0.35 + 0.65 * p),
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2
            ..color =
                JarvisColors.alpha(JarvisColors.turquoise, (1 - p) * 0.55),
        );
      }
    }

    // Speaking: wavy ring
    if (state == JarvisState.speaking) {
      final path = Path();
      const steps = 120;
      for (var s = 0; s <= steps; s++) {
        final th = s / steps * 2 * math.pi;
        final amp = r * 0.035 * (0.6 + 0.4 * math.sin(a * 2));
        final rad = r * 0.46 + amp * math.sin(th * 8 + a * 2);
        final p = Offset(c.dx + rad * math.cos(th), c.dy + rad * math.sin(th));
        if (s == 0) {
          path.moveTo(p.dx, p.dy);
        } else {
          path.lineTo(p.dx, p.dy);
        }
      }
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = JarvisColors.alpha(JarvisColors.turquoise, 0.9),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) =>
      old.t != t || old.state != state || old.dark != dark;
}
