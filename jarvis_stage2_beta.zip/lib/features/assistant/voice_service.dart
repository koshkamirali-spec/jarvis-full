import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

/// Wraps speech-to-text and text-to-speech.
class VoiceService {
  final SpeechToText _stt = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _sttReady = false;
  bool _delivered = true;
  String _last = '';
  void Function(String)? _onFinal;
  void Function()? _onEnd;

  /// True when no recognizer for the requested language was found.
  bool localeMissing = false;

  Future<bool> _ensureStt() async {
    if (_sttReady) return true;
    try {
      _sttReady = await _stt.initialize(
        onStatus: (status) {
          if (status == 'done') _finish();
        },
        onError: (_) => _finish(),
      );
    } catch (_) {
      _sttReady = false;
    }
    return _sttReady;
  }

  void _finish() {
    if (_delivered) return;
    _delivered = true;
    if (_last.trim().isNotEmpty) {
      _onFinal?.call(_last);
    } else {
      _onEnd?.call();
    }
  }

  Future<String?> _pickLocale(String lang) async {
    try {
      final locales = await _stt.locales();
      for (final l in locales) {
        final id = l.localeId.toLowerCase().replaceAll('-', '_');
        if (id == lang || id.startsWith('${lang}_')) return l.localeId;
      }
    } catch (_) {}
    return null;
  }

  Future<bool> listen({
    required String lang,
    required void Function(String) onPartial,
    required void Function(String) onFinal,
    required void Function() onEnd,
  }) async {
    if (!await _ensureStt()) return false;
    _delivered = false;
    _last = '';
    _onFinal = onFinal;
    _onEnd = onEnd;
    final localeId = await _pickLocale(lang);
    localeMissing = localeId == null;
    try {
      await _stt.listen(
        onResult: (SpeechRecognitionResult r) {
          _last = r.recognizedWords;
          if (r.finalResult) {
            if (!_delivered) {
              _delivered = true;
              if (_last.trim().isNotEmpty) {
                onFinal(_last);
              } else {
                onEnd();
              }
            }
          } else {
            onPartial(_last);
          }
        },
        localeId: localeId,
        listenFor: const Duration(seconds: 30),
        pauseFor: const Duration(seconds: 3),
      );
    } catch (_) {
      _delivered = true;
      return false;
    }
    return true;
  }

  /// Stops listening; a final result is still delivered.
  Future<void> stopListening() async {
    try {
      await _stt.stop();
    } catch (_) {}
  }

  /// Cancels listening and discards any result.
  Future<void> cancelListening() async {
    _delivered = true;
    try {
      await _stt.cancel();
    } catch (_) {}
  }

  String _clean(String t) => t
      .replaceAll(RegExp(r'[*_#`>]+'), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  Future<void> speak(String text, {required String lang, double rate = 0.5}) async {
    final clean = _clean(text);
    if (clean.isEmpty) return;
    try {
      await _tts.setLanguage(lang == 'fa' ? 'fa-IR' : 'en-US');
      await _tts.setSpeechRate(rate);
      await _tts.awaitSpeakCompletion(true);
      await _tts.speak(clean).timeout(const Duration(seconds: 90));
    } catch (_) {}
  }

  Future<void> stopSpeaking() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }

  Future<void> dispose() async {
    await cancelListening();
    await stopSpeaking();
  }
}
