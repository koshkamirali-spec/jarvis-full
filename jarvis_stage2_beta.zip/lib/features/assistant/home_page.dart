import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/strings.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/storage/api_key_store.dart';
import '../../core/theme/jarvis_colors.dart';
import '../../core/widgets/glass_panel.dart';
import '../system/system_status.dart';
import 'assistant_controller.dart';
import 'jarvis_orb.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final settings = ref.watch(settingsProvider);
    final a = ref.watch(assistantProvider);
    final dark = Theme.of(context).brightness == Brightness.dark;

    final subtitle = (a.orb == JarvisState.listening && a.partial.isNotEmpty)
        ? a.partial
        : (a.messages.isNotEmpty && !a.messages.last.isUser
            ? a.messages.last.text
            : '');
    final label = a.orb == JarvisState.idle ? s.t('tapMic') : s.t(a.orb.name);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(0, -0.2),
            radius: 1.1,
            colors: dark
                ? [const Color(0xFF07182B), JarvisColors.bg]
                : [Colors.white, JarvisColors.lightBg],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        settings.assistantName,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            fontWeight: FontWeight.w600, letterSpacing: 1.2),
                      ),
                    ),
                    IconButton(
                      tooltip: s.t('settings'),
                      icon: const Icon(Icons.settings_outlined),
                      onPressed: () => context.push('/settings'),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                const _ClockPanel(),
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, c) {
                      final orbSize = (c.maxHeight * 0.58).clamp(130.0, 280.0);
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          JarvisOrb(state: a.orb, size: orbSize),
                          const SizedBox(height: 6),
                          Text(label,
                              style: Theme.of(context).textTheme.bodyLarge),
                          if (subtitle.isNotEmpty)
                            Flexible(
                              child: SingleChildScrollView(
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
                                  child: Text(
                                    subtitle,
                                    textAlign: TextAlign.center,
                                    style: Theme.of(context).textTheme.bodyMedium,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      );
                    },
                  ),
                ),
                const _ModulesRow(),
                const SizedBox(height: 10),
                const _StatusRow(),
                const SizedBox(height: 14),
                _MicButton(
                  icon: a.orb == JarvisState.idle
                      ? Icons.mic
                      : (a.orb == JarvisState.thinking
                          ? Icons.hourglass_top
                          : Icons.stop),
                  onTap: () => ref.read(assistantProvider.notifier).toggleMic(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ModulesRow extends StatelessWidget {
  const _ModulesRow();

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final items = <_Module>[
      _Module(Icons.chat_bubble_outline, 'chat', '/chat'),
      _Module(Icons.camera_alt_outlined, 'vision', '/vision'),
      _Module(Icons.shield_outlined, 'emergency', '/emergency'),
      _Module(Icons.psychology_alt_outlined, 'memory', '/memory'),
      _Module(Icons.checklist, 'planner', '/planner'),
    ];
    return Row(
      children: [
        for (final m in items)
          Expanded(
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => context.push(m.route),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(
                  children: [
                    Icon(m.icon,
                        size: 26, color: Theme.of(context).colorScheme.primary),
                    const SizedBox(height: 4),
                    Text(s.t(m.key),
                        style: Theme.of(context).textTheme.labelSmall),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _Module {
  const _Module(this.icon, this.key, this.route);
  final IconData icon;
  final String key;
  final String route;
}

class _ClockPanel extends ConsumerWidget {
  const _ClockPanel();

  String _two(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final now = ref.watch(clockProvider).value ?? DateTime.now();
    return GlassPanel(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            '${_two(now.hour)}:${_two(now.minute)}',
            style: Theme.of(context)
                .textTheme
                .headlineMedium
                ?.copyWith(fontWeight: FontWeight.w300, letterSpacing: 2),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(s.weekday(now.weekday)),
              Text('${now.year}/${_two(now.month)}/${_two(now.day)}'),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatusRow extends ConsumerWidget {
  const _StatusRow();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(context);
    final battery = ref.watch(batteryProvider).value;
    final conn = ref.watch(connectivityProvider).value;
    final hasKey = ref.watch(apiKeyProvider) != null;

    final batteryText = battery == null || battery.level < 0
        ? s.t('unknown')
        : '${battery.level}%${battery.charging ? ' • ${s.t('charging')}' : ''}';

    String netText;
    IconData netIcon;
    if (conn == null) {
      netText = s.t('unknown');
      netIcon = Icons.help_outline;
    } else if (conn.contains(ConnectivityResult.wifi)) {
      netText = s.t('wifi');
      netIcon = Icons.wifi;
    } else if (conn.contains(ConnectivityResult.mobile)) {
      netText = s.t('mobile');
      netIcon = Icons.signal_cellular_alt;
    } else if (conn.contains(ConnectivityResult.ethernet)) {
      netText = s.t('ethernet');
      netIcon = Icons.settings_ethernet;
    } else {
      netText = s.t('offline');
      netIcon = Icons.wifi_off;
    }

    return Row(
      children: [
        Expanded(
          child: _StatusChip(
            icon: battery != null && battery.charging
                ? Icons.battery_charging_full
                : Icons.battery_std,
            title: s.t('battery'),
            value: batteryText,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child:
              _StatusChip(icon: netIcon, title: s.t('network'), value: netText),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: _StatusChip(
            icon: Icons.psychology_outlined,
            title: s.t('ai'),
            value: hasKey ? s.t('aiReady') : s.t('aiNotConnected'),
          ),
        ),
      ],
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip(
      {required this.icon, required this.title, required this.value});
  final IconData icon;
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GlassPanel(
      radius: 16,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      child: Column(
        children: [
          Icon(icon, size: 20, color: theme.colorScheme.primary),
          const SizedBox(height: 4),
          Text(title, style: theme.textTheme.labelSmall),
          const SizedBox(height: 2),
          Text(
            value,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.bodySmall
                ?.copyWith(fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class _MicButton extends StatelessWidget {
  const _MicButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 84,
      height: 84,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [JarvisColors.cyan, JarvisColors.electric],
        ),
        boxShadow: [
          BoxShadow(
            color: JarvisColors.alpha(JarvisColors.cyan, 0.5),
            blurRadius: 28,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Icon(icon, size: 40, color: Colors.black),
        ),
      ),
    );
  }
}
