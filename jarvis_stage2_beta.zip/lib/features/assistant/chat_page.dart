import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/theme/jarvis_colors.dart';
import 'assistant_controller.dart';
import 'jarvis_orb.dart';

class ChatPage extends ConsumerStatefulWidget {
  const ChatPage({super.key});

  @override
  ConsumerState<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends ConsumerState<ChatPage> {
  final _text = TextEditingController();
  final _scroll = ScrollController();

  @override
  void dispose() {
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _send() {
    final t = _text.text;
    if (t.trim().isEmpty) return;
    _text.clear();
    ref.read(assistantProvider.notifier).submitText(t);
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final a = ref.watch(assistantProvider);
    final cs = Theme.of(context).colorScheme;

    ref.listen<int>(assistantProvider.select((st) => st.messages.length),
        (prev, next) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(
            _scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOut,
          );
        }
      });
    });

    return Scaffold(
      appBar: AppBar(title: Text(s.t('chat'))),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.all(12),
              itemCount: a.messages.length,
              itemBuilder: (context, i) {
                final m = a.messages[i];
                return Align(
                  alignment: m.isUser
                      ? AlignmentDirectional.centerEnd
                      : AlignmentDirectional.centerStart,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    constraints: const BoxConstraints(maxWidth: 320),
                    decoration: BoxDecoration(
                      color: JarvisColors.alpha(
                          m.isUser ? cs.primary : cs.secondary, 0.18),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                          color: JarvisColors.alpha(cs.primary, 0.3)),
                    ),
                    child: SelectableText(m.text),
                  ),
                );
              },
            ),
          ),
          if (a.orb == JarvisState.thinking) const LinearProgressIndicator(),
          if (a.orb == JarvisState.listening && a.partial.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Text(a.partial,
                  style: Theme.of(context).textTheme.bodySmall),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _text,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: InputDecoration(
                        hintText: s.t('typeMessage'),
                        border: const OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(a.orb == JarvisState.idle ? Icons.mic : Icons.stop),
                    onPressed: () =>
                        ref.read(assistantProvider.notifier).toggleMic(),
                  ),
                  IconButton(
                    tooltip: s.t('send'),
                    icon: const Icon(Icons.send),
                    onPressed: _send,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
