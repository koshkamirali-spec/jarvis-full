import 'package:url_launcher/url_launcher.dart';

class CommandResult {
  const CommandResult(this.reply, {this.route});
  final String reply;
  final String? route;
}

class _App {
  const _App(this.name, this.keys, this.scheme, this.web);
  final String name;
  final List<String> keys;
  final String scheme;
  final String web;
}

/// Handles built-in voice/text commands before falling back to the AI.
class CommandRouter {
  CommandRouter({required this.lang, required this.addTask});

  final String lang;
  final Future<void> Function(String task) addTask;

  static const _apps = <_App>[
    _App('Instagram', ['اینستاگرام', 'اینستا', 'instagram'], 'instagram://app',
        'https://www.instagram.com'),
    _App('Telegram', ['تلگرام', 'telegram'], 'tg://', 'https://web.telegram.org'),
    _App('WhatsApp', ['واتساپ', 'واتس اپ', 'whatsapp'], 'whatsapp://',
        'https://web.whatsapp.com'),
    _App('YouTube', ['یوتیوب', 'youtube'], 'vnd.youtube://',
        'https://www.youtube.com'),
    _App('Browser', ['مرورگر', 'browser', 'chrome', 'کروم'],
        'https://www.google.com', 'https://www.google.com'),
  ];

  static const _stopWords = {'توقف', 'لغو', 'بس', 'ساکت', 'stop', 'cancel'};

  String _t(String fa, String en) => lang == 'fa' ? fa : en;

  String _norm(String s) => s
      .toLowerCase()
      .replaceAll('\u064a', '\u06cc')
      .replaceAll('\u0643', '\u06a9')
      .replaceAll('\u200c', ' ')
      .replaceAll(RegExp(r'[.,!?\u061f\u060c]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();

  bool _has(String t, List<String> keys) => keys.any(t.contains);

  String _two(int n) => n.toString().padLeft(2, '0');

  Future<CommandResult?> tryHandle(String raw) async {
    final t = _norm(raw);
    if (t.isEmpty) return null;

    // Emergency keywords: only opens the emergency screen, never auto-sends.
    if (RegExp('^(danger|\u062f\u0646\u062c\u0631|\u062e\u0637\u0631)( (1|2|\u06f1|\u06f2|\u06cc\u06a9|\u062f\u0648))?\$')
        .hasMatch(t)) {
      return CommandResult(
        _t('صفحه اضطراری باز شد. بدون تأیید شما هیچ پیام یا تماسی انجام نمی‌شود.',
            'Emergency screen opened. Nothing is sent or called without your confirmation.'),
        route: '/emergency',
      );
    }

    final task = RegExp(r'^(?:کار جدید|وظیفه جدید|add task|new task) (.+)$')
        .firstMatch(t);
    if (task != null) {
      final text = task.group(1)!;
      await addTask(text);
      return CommandResult(_t('به کارها اضافه شد: $text', 'Task added: $text'));
    }

    if (_stopWords.contains(t)) {
      return CommandResult(_t('باشه.', 'Okay.'));
    }

    final now = DateTime.now();
    if (_has(t, ['ساعت چنده', 'ساعت چند', 'چه ساعتی', 'what time', 'time is it'])) {
      final hm = '${_two(now.hour)}:${_two(now.minute)}';
      return CommandResult(_t('ساعت $hm است.', 'It is $hm.'));
    }
    if (_has(t, ['تاریخ امروز', 'امروز چندم', 'what date', 'today date'])) {
      final d = '${now.year}/${_two(now.month)}/${_two(now.day)}';
      return CommandResult(_t('تاریخ امروز $d است.', 'Today is $d.'));
    }

    final wantsOpen =
        _has(t, ['باز کن', 'بازکن', 'باز کنید', 'اجرا کن', 'open', 'launch']);
    if (!wantsOpen) return null;

    if (_has(t, ['دوربین', 'camera'])) {
      return CommandResult(_t('دوربین باز شد.', 'Camera opened.'),
          route: '/vision');
    }
    if (_has(t, ['تنظیمات', 'settings'])) {
      return CommandResult(_t('تنظیمات باز شد.', 'Settings opened.'),
          route: '/settings');
    }
    for (final a in _apps) {
      if (_has(t, a.keys)) {
        final ok = await _launch(a);
        return CommandResult(ok
            ? _t('${a.name} باز شد.', 'Opening ${a.name}.')
            : _t('نتوانستم ${a.name} را باز کنم.',
                'I could not open ${a.name}.'));
      }
    }
    return null;
  }

  Future<bool> _launch(_App a) async {
    try {
      if (await launchUrl(Uri.parse(a.scheme),
          mode: LaunchMode.externalApplication)) {
        return true;
      }
    } catch (_) {}
    try {
      return await launchUrl(Uri.parse(a.web),
          mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }
}
