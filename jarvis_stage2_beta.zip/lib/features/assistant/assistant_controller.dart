import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/strings.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/storage/api_key_store.dart';
import '../../core/storage/json_list_store.dart';
import 'ai_service.dart';
import 'command_router.dart';
import 'jarvis_orb.dart';
import 'voice_service.dart';

class ChatMessage {
  const ChatMessage(this.role, this.text);
  final String role; // 'user' | 'assistant'
  final String text;
  bool get isUser => role == 'user';
}

class AssistantState {
  const AssistantState({
    this.orb = JarvisState.idle,
    this.messages = const [],
    this.partial = '',
    this.navigateTo,
  });

  final JarvisState orb;
  final List<ChatMessage> messages;
  final String partial;
  final String? navigateTo;

  AssistantState copyWith({
    JarvisState? orb,
    List<ChatMessage>? messages,
    String? partial,
    String? navigateTo,
    bool clearNavigate = false,
  }) =>
      AssistantState(
        orb: orb ?? this.orb,
        messages: messages ?? this.messages,
        partial: partial ?? this.partial,
        navigateTo: clearNavigate ? null : (navigateTo ?? this.navigateTo),
      );
}

final assistantProvider =
    StateNotifierProvider<AssistantController, AssistantState>(
  (ref) => AssistantController(ref),
);

class AssistantController extends StateNotifier<AssistantState> {
  AssistantController(this._ref) : super(const AssistantState());

  final Ref _ref;
  final VoiceService _voice = VoiceService();
  final AiService _ai = AiService();
  bool _localeWarned = false;

  String get _lang => _ref.read(settingsProvider).languageCode;
  S get _s => S(_lang);

  void _setOrb(JarvisState o) {
    if (mounted) state = state.copyWith(orb: o);
  }

  void _add(String role, String text) {
    if (mounted) {
      state = state.copyWith(messages: [...state.messages, ChatMessage(role, text)]);
    }
  }

  void clearNavigation() {
    if (mounted) state = state.copyWith(clearNavigate: true);
  }

  String _systemPrompt() {
    final s = _ref.read(settingsProvider);
    final b = StringBuffer()
      ..writeln('You are ${s.assistantName}, a personal voice assistant inside the J.A.R.V.I.S mobile app.')
      ..writeln('Reply in the same language the user writes in (default: ${s.languageCode == 'fa' ? 'Persian' : 'English'}).')
      ..writeln('Replies are often spoken aloud: keep them short (1-3 sentences) unless the user asks for detail. Avoid markdown, lists and emojis.')
      ..writeln('Be honest about limits. You cannot control the phone except through commands the app already handles.');
    if (s.memoryEnabled) {
      final facts = _ref
          .read(memoryProvider)
          .map((e) => e['text'])
          .whereType<String>()
          .toList();
      if (facts.isNotEmpty) {
        b.writeln('Facts the user chose to share with you:');
        for (final f in facts) {
          b.writeln('- $f');
        }
      }
    }
    return b.toString();
  }

  // ---------------- voice ----------------

  Future<void> toggleMic() async {
    switch (state.orb) {
      case JarvisState.listening:
        await _voice.cancelListening();
        state = state.copyWith(orb: JarvisState.idle, partial: '');
        return;
      case JarvisState.speaking:
        await _voice.stopSpeaking();
        _setOrb(JarvisState.idle);
        return;
      case JarvisState.thinking:
        return;
      case JarvisState.idle:
        break;
    }

    await _voice.stopSpeaking();
    final ok = await _voice.listen(
      lang: _lang,
      onPartial: (t) {
        if (mounted) state = state.copyWith(partial: t);
      },
      onFinal: (t) => _onSpeech(t),
      onEnd: () {
        if (mounted && state.orb == JarvisState.listening) {
          state = state.copyWith(orb: JarvisState.idle, partial: '');
        }
      },
    );
    if (!ok) {
      _add('assistant', _s.t('micFail'));
      _setOrb(JarvisState.idle);
      return;
    }
    state = state.copyWith(orb: JarvisState.listening, partial: '');
    if (_voice.localeMissing && _lang == 'fa' && !_localeWarned) {
      _localeWarned = true;
      _add('assistant', _s.t('faMissing'));
    }
  }

  Future<void> _onSpeech(String text) async {
    if (!mounted) return;
    state = state.copyWith(partial: '');
    await submitText(text);
  }

  // ---------------- text / commands / AI ----------------

  Future<void> submitText(String raw) async {
    final text = raw.trim();
    if (text.isEmpty) {
      _setOrb(JarvisState.idle);
      return;
    }
    await _voice.stopSpeaking();
    _add('user', text);
    _setOrb(JarvisState.thinking);

    final router = CommandRouter(
      lang: _lang,
      addTask: (t) =>
          _ref.read(tasksProvider.notifier).add({'text': t, 'done': false}),
    );
    final cmd = await router.tryHandle(text);
    if (cmd != null) {
      _add('assistant', cmd.reply);
      if (cmd.route != null && mounted) {
        state = state.copyWith(navigateTo: cmd.route);
      }
      await _speak(cmd.reply);
      return;
    }
    await _ask();
  }

  Future<void> _ask() async {
    final key = _ref.read(apiKeyProvider);
    if (key == null || key.isEmpty) {
      _add('assistant', _s.t('noKey'));
      _setOrb(JarvisState.idle);
      return;
    }
    try {
      final all = state.messages;
      final recent = all.length > 12 ? all.sublist(all.length - 12) : all;
      final turns = [for (final m in recent) ChatTurn(m.role, m.text)];
      while (turns.isNotEmpty && turns.first.role != 'user') {
        turns.removeAt(0);
      }
      final reply = await _ai.chat(
        apiKey: key,
        system: _systemPrompt(),
        turns: turns,
      );
      _add('assistant', reply);
      await _speak(reply);
    } catch (e) {
      _add('assistant', errorText(e, _lang));
      _setOrb(JarvisState.idle);
    }
  }

  Future<void> _speak(String text) async {
    final settings = _ref.read(settingsProvider);
    if (!settings.speakReplies || text.trim().isEmpty) {
      _setOrb(JarvisState.idle);
      return;
    }
    _setOrb(JarvisState.speaking);
    await _voice.speak(text, lang: settings.languageCode, rate: settings.speechRate);
    if (mounted && state.orb == JarvisState.speaking) {
      _setOrb(JarvisState.idle);
    }
  }

  /// Reads any text aloud (used by the Vision page).
  Future<void> speakText(String text) async {
    await _voice.stopSpeaking();
    final settings = _ref.read(settingsProvider);
    _setOrb(JarvisState.speaking);
    await _voice.speak(text, lang: settings.languageCode, rate: settings.speechRate);
    if (mounted && state.orb == JarvisState.speaking) {
      _setOrb(JarvisState.idle);
    }
  }

  // ---------------- vision ----------------

  Future<String> analyzeImage(Uint8List bytes, String prompt) async {
    final key = _ref.read(apiKeyProvider);
    if (key == null || key.isEmpty) {
      throw const AiException(detail: 'nokey');
    }
    _setOrb(JarvisState.thinking);
    try {
      return await _ai.vision(
        apiKey: key,
        system: _systemPrompt(),
        image: bytes,
        prompt: prompt,
      );
    } finally {
      _setOrb(JarvisState.idle);
    }
  }

  static String errorText(Object e, String lang) {
    final s = S(lang);
    if (e is AiException) {
      if (e.detail == 'nokey') return s.t('noKey');
      if (e.network) return s.t('errNet');
      if (e.status == 401 || e.status == 403) return s.t('errKey');
      if (e.status == 429) return s.t('errRate');
      if (e.status != null) return '${s.t('errGeneric')} (${e.status})';
    }
    return s.t('errGeneric');
  }

  @override
  void dispose() {
    _voice.dispose();
    super.dispose();
  }
}
