import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

class ChatTurn {
  const ChatTurn(this.role, this.text);
  final String role; // 'user' | 'assistant'
  final String text;
}

class AiException implements Exception {
  const AiException({this.status, this.network = false, this.detail = ''});
  final int? status;
  final bool network;
  final String detail;

  @override
  String toString() => 'AiException(status=$status, network=$network, $detail)';
}

/// Minimal client for the Anthropic Messages API.
/// Beta: the key is entered by the user and stored on-device.
class AiService {
  static const String model = 'claude-sonnet-5-5';
  static final Uri _endpoint =
      Uri.parse('https://api.anthropic.com/v1/messages');

  Future<String> chat({
    required String apiKey,
    required String system,
    required List<ChatTurn> turns,
  }) {
    final messages = <Map<String, Object>>[
      for (final t in turns) {'role': t.role, 'content': t.text},
    ];
    return _post(apiKey, system, messages);
  }

  Future<String> vision({
    required String apiKey,
    required String system,
    required Uint8List image,
    required String prompt,
  }) {
    final messages = <Map<String, Object>>[
      {
        'role': 'user',
        'content': [
          {
            'type': 'image',
            'source': {
              'type': 'base64',
              'media_type': _mediaType(image),
              'data': base64Encode(image),
            },
          },
          {'type': 'text', 'text': prompt},
        ],
      },
    ];
    return _post(apiKey, system, messages);
  }

  String _mediaType(Uint8List b) {
    if (b.length > 3 && b[0] == 0x89 && b[1] == 0x50) return 'image/png';
    if (b.length > 3 && b[0] == 0x52 && b[1] == 0x49) return 'image/webp';
    return 'image/jpeg';
  }

  Future<String> _post(
    String apiKey,
    String system,
    List<Map<String, Object>> messages,
  ) async {
    try {
      final res = await http
          .post(
            _endpoint,
            headers: {
              'x-api-key': apiKey,
              'anthropic-version': '2023-06-01',
              'content-type': 'application/json; charset=utf-8',
            },
            body: jsonEncode({
              'model': model,
              'max_tokens': 800,
              'system': system,
              'messages': messages,
            }),
          )
          .timeout(const Duration(seconds: 60));

      final body = utf8.decode(res.bodyBytes, allowMalformed: true);
      if (res.statusCode != 200) {
        throw AiException(status: res.statusCode, detail: body);
      }
      final data = jsonDecode(body) as Map<String, dynamic>;
      final content = data['content'];
      if (content is! List) throw const AiException(detail: 'bad response');
      final text = content
          .whereType<Map>()
          .where((b) => b['type'] == 'text')
          .map((b) => (b['text'] as String?) ?? '')
          .join('\n')
          .trim();
      if (text.isEmpty) throw const AiException(detail: 'empty response');
      return text;
    } on TimeoutException {
      throw const AiException(network: true, detail: 'timeout');
    } on SocketException {
      throw const AiException(network: true, detail: 'socket');
    } on http.ClientException {
      throw const AiException(network: true, detail: 'client');
    }
  }
}
