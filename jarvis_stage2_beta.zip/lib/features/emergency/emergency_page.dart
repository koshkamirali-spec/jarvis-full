import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/l10n/strings.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/storage/json_list_store.dart';

/// Emergency tools. Nothing is called or sent automatically:
/// every action is chosen by the user and finished in the phone's own apps.
class EmergencyPage extends ConsumerStatefulWidget {
  const EmergencyPage({super.key});

  @override
  ConsumerState<EmergencyPage> createState() => _EmergencyPageState();
}

class _EmergencyPageState extends ConsumerState<EmergencyPage> {
  late final TextEditingController _number;

  @override
  void initState() {
    super.initState();
    _number =
        TextEditingController(text: ref.read(settingsProvider).emergencyNumber);
  }

  @override
  void dispose() {
    _number.dispose();
    super.dispose();
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _call(String number) async {
    final n = number.replaceAll(RegExp(r'\s'), '');
    if (n.isEmpty) return;
    try {
      await launchUrl(Uri.parse('tel:$n'));
    } catch (_) {}
  }

  Future<String?> _locationLink() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission();
      }
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        return null;
      }
      final p = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 12),
        ),
      );
      return 'https://maps.google.com/?q=${p.latitude},${p.longitude}';
    } catch (_) {
      return null;
    }
  }

  Future<void> _prepareSms() async {
    final s = S.of(context);
    final numbers = ref
        .read(contactsProvider)
        .map((c) => (c['phone'] as String?) ?? '')
        .where((p) => p.isNotEmpty)
        .toList();
    if (numbers.isEmpty) {
      _snack(s.t('noContacts'));
      return;
    }
    var body = s.t('smsBody');
    final link = await _locationLink();
    if (link != null) {
      body = '$body $link';
    } else {
      _snack(s.t('locationFail'));
    }
    final uri = Uri.parse(
        'sms:${numbers.join(',')}?body=${Uri.encodeComponent(body)}');
    try {
      await launchUrl(uri);
    } catch (_) {}
  }

  Future<void> _showActions() async {
    final s = S.of(context);
    final contacts = ref.read(contactsProvider);
    final emNumber = ref.read(settingsProvider).emergencyNumber;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('emergencyDialogTitle')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(s.t('emergencyNote'),
                style: Theme.of(ctx).textTheme.bodySmall),
            const SizedBox(height: 12),
            if (emNumber.isNotEmpty)
              FilledButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  _call(emNumber);
                },
                child: Text('${s.t('callEmergency')} ($emNumber)'),
              ),
            if (contacts.isNotEmpty) ...[
              const SizedBox(height: 8),
              FilledButton.tonal(
                onPressed: () {
                  Navigator.pop(ctx);
                  _call((contacts.first['phone'] as String?) ?? '');
                },
                child: Text(s.t('callContact')),
              ),
            ],
            const SizedBox(height: 8),
            FilledButton.tonal(
              onPressed: () {
                Navigator.pop(ctx);
                _prepareSms();
              },
              child: Text(s.t('smsLocation')),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(s.t('cancel')),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _addContact() async {
    final s = S.of(context);
    final name = TextEditingController();
    final phone = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.t('addContact')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              decoration: InputDecoration(labelText: s.t('name')),
            ),
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(labelText: s.t('phone')),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(s.t('cancel'))),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(s.t('add'))),
        ],
      ),
    );
    final p = phone.text.replaceAll(RegExp(r'\s'), '');
    if (ok == true && p.isNotEmpty) {
      await ref
          .read(contactsProvider.notifier)
          .add({'name': name.text.trim(), 'phone': p});
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);
    final contacts = ref.watch(contactsProvider);

    return Scaffold(
      appBar: AppBar(title: Text(s.t('emergency'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SizedBox(
            height: 72,
            child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
              onPressed: _showActions,
              child: Text(s.t('emergency'),
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(height: 8),
          Text(s.t('emergencyNote'), style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 20),
          TextField(
            controller: _number,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
              labelText: s.t('emergencyNumber'),
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.check),
                onPressed: () async {
                  await ref
                      .read(settingsProvider.notifier)
                      .setEmergencyNumber(_number.text);
                  _snack(s.t('saved'));
                },
              ),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: Text(s.t('contacts'),
                    style: Theme.of(context).textTheme.titleMedium),
              ),
              IconButton(
                tooltip: s.t('addContact'),
                icon: const Icon(Icons.person_add_alt),
                onPressed: _addContact,
              ),
            ],
          ),
          if (contacts.isEmpty)
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(s.t('noContacts')),
            ),
          for (var i = 0; i < contacts.length; i++)
            ListTile(
              leading: const Icon(Icons.person_outline),
              title: Text((contacts[i]['name'] as String?)?.isNotEmpty == true
                  ? contacts[i]['name'] as String
                  : (contacts[i]['phone'] as String? ?? '')),
              subtitle: Text((contacts[i]['phone'] as String?) ?? ''),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () =>
                    ref.read(contactsProvider.notifier).removeAt(i),
              ),
            ),
        ],
      ),
    );
  }
}
