import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Ticks every second.
final clockProvider = StreamProvider.autoDispose<DateTime>((ref) async* {
  while (true) {
    yield DateTime.now();
    await Future<void>.delayed(const Duration(seconds: 1));
  }
});

class BatteryInfo {
  const BatteryInfo(this.level, this.state);
  final int level; // -1 when unavailable
  final BatteryState state;
  bool get charging =>
      state == BatteryState.charging || state == BatteryState.full;
}

final batteryProvider = StreamProvider.autoDispose<BatteryInfo>((ref) async* {
  final battery = Battery();
  while (true) {
    try {
      yield BatteryInfo(await battery.batteryLevel, await battery.batteryState);
    } catch (_) {
      yield const BatteryInfo(-1, BatteryState.unknown);
    }
    await Future<void>.delayed(const Duration(seconds: 30));
  }
});

/// Reports the active network *interface*, not proven internet access.
final connectivityProvider =
    StreamProvider.autoDispose<List<ConnectivityResult>>((ref) async* {
  final connectivity = Connectivity();
  yield await connectivity.checkConnectivity();
  yield* connectivity.onConnectivityChanged;
});
