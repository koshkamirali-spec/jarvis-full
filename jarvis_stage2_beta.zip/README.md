# J.A.R.V.I.S - Beta 0.2

Upload this zip to the repo root (GitHub Actions unzips it and builds the APK).

## Real in this beta
- Voice conversation: speech-to-text (fa/en) -> AI -> text-to-speech
- Text chat with history (last 12 messages sent as context)
- Voice commands: open Instagram / Telegram / WhatsApp / YouTube / browser,
  time, date, add task ("کار جدید ..."), stop, "danger" -> emergency screen
- Vision: camera/gallery -> describe, read text (OCR), identify
- Emergency: trusted contacts, call, SMS draft with location (user presses send)
- Memory (user-added facts used in replies), planner (tasks)
- Settings: API key (encrypted), language, theme, speech speed, assistant name

## Needs setup
- Anthropic API key: Settings -> API key (stored in Android Keystore storage)

## Not in beta (next stages)
- "Hey Jarvis" background wake word, offline AI model, web search, reminders
  with notifications, smart modes, file manager, gallery, backup
